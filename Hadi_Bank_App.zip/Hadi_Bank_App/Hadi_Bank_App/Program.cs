﻿using System;
using System.Collections.Generic;

namespace Bank
{
    class Program
    {
        static List<BankAccount> accounts = new List<BankAccount>();

        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("HSM Bank");
                Console.WriteLine("\n1. Account Registration\n2. Payment Deposit\n3. Payment Withdraw\n4. Check Account Balance");
                int input = Convert.ToInt32(Console.ReadLine());

                if (input == 1)
                {
                    CreateAccount();
                }
                else if (input == 2)
                {
                    Deposit();
                }
                else if (input == 3)
                {
                    Withdraw();
                }
                else if (input == 4)
                {
                    CheckBalance();
                }
                else
                {
                    Console.WriteLine("Invalid option. Please try again.");
                }
            }
        }

        static void CreateAccount()
        {
            BankAccount newAccount = new BankAccount();

            Console.WriteLine("Enter account number:");
            newAccount.AccountNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter owner name:");
            newAccount.Owner = Console.ReadLine();

            newAccount.Balance = 0; // Initial balance set to zero
            accounts.Add(newAccount);

            Console.WriteLine("Account created successfully!");
        }

        static void Deposit()
        {
            Console.WriteLine("Enter account number:");
            int accountNumber = Convert.ToInt32(Console.ReadLine());
            BankAccount account = FindAccount(accountNumber);

            if (account != null)
            {
                Console.WriteLine("Enter deposit amount:");
                decimal amount = Convert.ToDecimal(Console.ReadLine());
                account.Balance += amount;
                Console.WriteLine($"Deposited {amount}. New balance: {account.Balance}");
            }
            else
            {
                Console.WriteLine("Account not found.");
            }
        }

        static void Withdraw()
        {
            Console.WriteLine("Enter account number:");
            int accountNumber = Convert.ToInt32(Console.ReadLine());
            BankAccount account = FindAccount(accountNumber);

            if (account != null)
            {
                Console.WriteLine("Enter withdrawal amount:");
                decimal amount = Convert.ToDecimal(Console.ReadLine());

                if (amount <= account.Balance)
                {
                    account.Balance -= amount;
                    Console.WriteLine($"Withdrew {amount}. New balance: {account.Balance}");
                }
                else
                {
                    Console.WriteLine("Insufficient funds.");
                }
            }
            else
            {
                Console.WriteLine("Account not found.");
            }
        }

        static void CheckBalance()
        {
            Console.WriteLine("Enter account number:");
            int accountNumber = Convert.ToInt32(Console.ReadLine());
            BankAccount account = FindAccount(accountNumber);

            if (account != null)
            {
                Console.WriteLine($"Account No: {account.AccountNumber}, Owner: {account.Owner}, Balance: {account.Balance}");
            }
            else
            {
                Console.WriteLine("Account not found.");
            }
        }

        static BankAccount FindAccount(int accountNumber)
        {
            foreach (var acc in accounts)
            {
                if (acc.AccountNumber == accountNumber)
                {
                    return acc;
                }
            }
            return null;
        }
    }

    class BankAccount
    {
        public int AccountNumber { get; set; }
        public string Owner { get; set; }
        public decimal Balance { get; set; }
    }
}
